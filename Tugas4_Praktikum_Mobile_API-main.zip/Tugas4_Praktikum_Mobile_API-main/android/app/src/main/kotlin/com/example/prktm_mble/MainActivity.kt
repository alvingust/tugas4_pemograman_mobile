package com.example.prktm_mble

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
